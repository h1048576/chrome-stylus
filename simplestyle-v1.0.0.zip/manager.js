'use strict';

/* ===== 存储层：扩展环境用 chrome.storage；直接双击打开页面预览时用 localStorage 模拟 ===== */
function createShim() {
  const KEY = 'simplestyle';
  const listeners = [];
  const read = () => {
    try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch (e) { return {}; }
  };
  return {
    async get(keys) {
      const data = read();
      const out = {};
      for (const k of [].concat(keys)) if (k in data) out[k] = data[k];
      return out;
    },
    async set(obj) {
      localStorage.setItem(KEY, JSON.stringify(Object.assign(read(), obj)));
      setTimeout(() => {
        const changes = {};
        for (const k in obj) changes[k] = { oldValue: null, newValue: obj[k] };
        listeners.forEach(fn => fn(changes, 'local'));
      }, 0);
    },
    onChanged: { addListener(fn) { listeners.push(fn); } },
  };
}

const extStorage = typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local;
const store = extStorage
  ? {
      get: keys => chrome.storage.local.get(keys),
      set: obj => chrome.storage.local.set(obj),
      onChanged: chrome.storage.onChanged,
    }
  : createShim();

/* ===== 状态 ===== */
let styles = [];
let selectedId = null;
let saveTimer = null;
let pendingSave = false;

const $ = sel => document.querySelector(sel);
const listEl = $('#style-list');
const metaEl = $('#meta-body');
const cssEditor = $('#css-editor');
const gutterEl = $('#gutter');
const cssInfo = $('#css-info');
const saveStatus = $('#save-status');
const themeBtn = $('#btn-theme');

const RULE_TYPES = [
  ['all', '所有'],
  ['url', 'URL'],
  ['prefix', '前缀'],
  ['domain', '域名'],
  ['regex', '正则'],
];
const PLACEHOLDERS = {
  all: '对全部页面生效，无需填写',
  url: '完整地址，如 https://example.com/page',
  prefix: '地址前缀，如 https://example.com/blog/',
  domain: '如 example.com（含子域名）',
  regex: '正则表达式，如 \\.pdf$',
};

const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const current = () => styles.find(s => s.id === selectedId) || null;

const EXAMPLE = {
  id: uid(),
  name: '示例：夜间模式',
  enabled: true,
  rules: [{ type: 'domain', value: 'example.com' }],
  css: '/* 把页面变成夜间模式 */\nhtml {\n  filter: invert(1) hue-rotate(180deg);\n}\nimg, video, iframe {\n  filter: invert(1) hue-rotate(180deg);\n}',
};

/* ===== 保存 ===== */
function setStatus(text) { saveStatus.textContent = text; }

function scheduleSave() {
  pendingSave = true;
  setStatus('编辑中…');
  clearTimeout(saveTimer);
  saveTimer = setTimeout(flushSave, 400);
}

function flushSave() {
  if (!pendingSave) return;
  pendingSave = false;
  clearTimeout(saveTimer);
  store.set({ styles });
  setStatus('已保存 ✓');
}

/* ===== 渲染 ===== */
function renderAll() { renderList(); renderMeta(); }

function renderList() {
  listEl.textContent = '';
  if (!styles.length) {
    const p = document.createElement('div');
    p.className = 'hint';
    p.textContent = '还没有样式，\n点击右上角「＋ 新建」';
    listEl.appendChild(p);
    return;
  }
  for (const s of styles) {
    const item = document.createElement('div');
    item.className = 'style-item' + (s.id === selectedId ? ' active' : '') + (s.enabled ? '' : ' off');
    item.title = s.name || '未命名';

    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.checked = !!s.enabled;
    cb.title = '启用 / 停用';
    cb.addEventListener('click', e => e.stopPropagation());
    cb.addEventListener('change', () => {
      s.enabled = cb.checked;
      item.classList.toggle('off', !s.enabled);
      scheduleSave();
    });

    const name = document.createElement('span');
    name.className = 'name';
    name.textContent = s.name || '未命名';

    const del = document.createElement('button');
    del.className = 'del';
    del.textContent = '×';
    del.title = '删除';
    del.addEventListener('click', e => {
      e.stopPropagation();
      removeStyle(s.id);
    });

    item.append(cb, name, del);
    item.addEventListener('click', () => {
      if (selectedId !== s.id) { selectedId = s.id; renderAll(); }
    });
    listEl.appendChild(item);
  }
}

function renderMeta() {
  const s = current();
  metaEl.textContent = '';
  if (!s) {
    const p = document.createElement('div');
    p.className = 'hint';
    p.textContent = '从左侧选择一个样式，或点击「＋ 新建」';
    metaEl.appendChild(p);
    cssEditor.value = '';
    cssEditor.disabled = true;
    updateGutter();
    cssInfo.textContent = '';
    return;
  }
  cssEditor.disabled = false;

  const lbName = document.createElement('div');
  lbName.className = 'field-label';
  lbName.textContent = '名称';

  const nameInput = document.createElement('input');
  nameInput.value = s.name || '';
  nameInput.placeholder = '样式名称';
  nameInput.addEventListener('input', () => {
    s.name = nameInput.value;
    renderList(); // 只重建左侧列表，当前输入框焦点不丢
    scheduleSave();
  });

  const lbRules = document.createElement('div');
  lbRules.className = 'field-label';
  lbRules.textContent = '生效范围（满足任意一条即生效）';

  const rulesBox = document.createElement('div');
  rulesBox.className = 'rules-box';
  s.rules.forEach((r, i) => rulesBox.appendChild(ruleRow(s, i)));

  const addRuleBtn = document.createElement('button');
  addRuleBtn.className = 'btn btn-ghost';
  addRuleBtn.textContent = '＋ 添加规则';
  addRuleBtn.addEventListener('click', () => {
    s.rules.push({ type: 'domain', value: '' });
    renderMeta();
    scheduleSave();
    const inputs = metaEl.querySelectorAll('.rule-row input');
    if (inputs.length) inputs[inputs.length - 1].focus();
  });

  const delBtn = document.createElement('button');
  delBtn.className = 'btn btn-danger';
  delBtn.textContent = '删除此样式';
  delBtn.addEventListener('click', () => removeStyle(s.id));

  metaEl.append(lbName, nameInput, lbRules, rulesBox, addRuleBtn, delBtn);

  cssEditor.value = s.css || '';
  updateGutter();
  updateCssInfo();
}

function ruleRow(s, index) {
  const r = s.rules[index];
  const row = document.createElement('div');
  row.className = 'rule-row';

  const sel = document.createElement('select');
  for (const [val, label] of RULE_TYPES) {
    const opt = document.createElement('option');
    opt.value = val;
    opt.textContent = label;
    if (r.type === val) opt.selected = true;
    sel.appendChild(opt);
  }
  sel.addEventListener('change', () => {
    r.type = sel.value;
    input.placeholder = PLACEHOLDERS[r.type] || '';
    input.disabled = r.type === 'all';
    validate();
    scheduleSave();
  });

  const input = document.createElement('input');
  input.value = r.value || '';
  input.placeholder = PLACEHOLDERS[r.type] || '';
  input.disabled = r.type === 'all';
  input.addEventListener('input', () => {
    r.value = input.value;
    validate();
    scheduleSave();
  });

  function validate() {
    let ok = true;
    if (r.type === 'regex' && (r.value || '').trim()) {
      try { new RegExp(r.value.trim()); } catch (e) { ok = false; }
    }
    input.classList.toggle('invalid', !ok);
    input.title = ok ? '' : '正则表达式语法有误';
  }
  validate();

  const del = document.createElement('button');
  del.className = 'del';
  del.textContent = '×';
  del.title = '删除规则';
  del.addEventListener('click', () => {
    s.rules.splice(index, 1);
    if (!s.rules.length) s.rules.push({ type: 'all', value: '' }); // 至少保留一条
    renderMeta();
    scheduleSave();
  });

  row.append(sel, input, del);
  return row;
}

function removeStyle(id) {
  const s = styles.find(x => x.id === id);
  if (!s) return;
  if (!confirm(`确定删除「${s.name || '未命名'}」吗？`)) return;
  styles = styles.filter(x => x.id !== id);
  if (selectedId === id) selectedId = styles.length ? styles[0].id : null;
  pendingSave = true;
  flushSave();
  renderAll();
}

/* ===== CSS 编辑器 ===== */
function updateGutter() {
  const lines = cssEditor.value.split('\n').length;
  let out = '';
  for (let i = 1; i <= lines; i++) out += i + '\n';
  gutterEl.textContent = out;
  gutterEl.scrollTop = cssEditor.scrollTop;
}

function updateCssInfo() {
  cssInfo.textContent = cssEditor.value.split('\n').length + ' 行';
}

cssEditor.addEventListener('input', () => {
  const s = current();
  if (!s) return;
  s.css = cssEditor.value;
  updateGutter();
  updateCssInfo();
  scheduleSave();
});

cssEditor.addEventListener('scroll', () => { gutterEl.scrollTop = cssEditor.scrollTop; });

cssEditor.addEventListener('keydown', e => {
  if (e.key === 'Tab' && !e.shiftKey && !e.ctrlKey && !e.metaKey) {
    e.preventDefault();
    cssEditor.setRangeText('  ', cssEditor.selectionStart, cssEditor.selectionEnd, 'end');
    cssEditor.dispatchEvent(new Event('input'));
  }
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
    e.preventDefault();
    flushSave();
  }
});

/* ===== 顶部按钮 ===== */
$('#btn-add').addEventListener('click', () => {
  const s = {
    id: uid(),
    name: '新样式',
    enabled: true,
    rules: [{ type: 'domain', value: '' }],
    css: '',
  };
  styles.push(s);
  selectedId = s.id;
  pendingSave = true;
  flushSave();
  renderAll();
});

/* ===== 主题：白天 / 夜间 ===== */
function applyTheme(t) {
  const dark = t === 'dark';
  document.body.classList.toggle('dark', dark);
  themeBtn.textContent = dark ? '☀️' : '🌙';
  themeBtn.title = dark ? '切换到白天模式' : '切换到夜间模式';
}

// 脚本加载时先按系统偏好应用，避免深色用户闪白；init 里再用已保存的选择覆盖
applyTheme(matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');

themeBtn.addEventListener('click', () => {
  const next = document.body.classList.contains('dark') ? 'light' : 'dark';
  applyTheme(next);
  store.set({ theme: next });
});

/* ===== 外部修改同步（其他标签页编辑时跟随更新） ===== */
store.onChanged.addListener(changes => {
  if (!changes.styles) return;
  const next = Array.isArray(changes.styles.newValue) ? changes.styles.newValue : [];
  if (JSON.stringify(next) === JSON.stringify(styles)) return;
  styles = next;
  if (!current()) selectedId = styles.length ? styles[0].id : null;
  const ae = document.activeElement;
  const editing = ae && (ae.tagName === 'INPUT' || ae.tagName === 'TEXTAREA' || ae.tagName === 'SELECT');
  renderList();
  if (!editing) renderMeta();
});

window.addEventListener('beforeunload', flushSave);

/* ===== 启动：首次使用时放入一条示例样式 ===== */
init();
async function init() {
  const data = await store.get(['styles', 'theme']);
  if (data.theme === 'dark' || data.theme === 'light') applyTheme(data.theme);
  if (Array.isArray(data.styles)) {
    styles = data.styles;
  } else {
    styles = [EXAMPLE];
    await store.set({ styles });
  }
  selectedId = styles.length ? styles[0].id : null;
  renderAll();
  setStatus('');
}
